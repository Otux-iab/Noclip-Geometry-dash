# Geometry-Dash-NoClip
- a simple internal geometry dash noclip!
- by simple i literally mean 30 lines of code simple
![alt text](https://cdn.discordapp.com/attachments/856362978986688556/895902437502775316/Working.PNG)
